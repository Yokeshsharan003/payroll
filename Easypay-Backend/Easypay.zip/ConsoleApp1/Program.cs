﻿using casestudy.EasypayApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace casestudy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EasyPayApplication repository = new EasyPayApplication();
            repository.HandleMainMenu();
        }
    }
}
