﻿using casestudy.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace casestudy.Service
{
    internal interface IHRManagement
    {
         int HRLogin();
         void AddEmployee();
         void RemoveEmployee();

         void UpdateEmployee();
         void AddUser();
         void RemoveUser();
        void UpdateUser();
        void DefinePayrollPolicy();
        void GeneratePayroll();
        List<ComplianceReportItem> GenerateComplianceReport();

    }
}
