﻿using casestudy.models;
using casestudy.DAO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;

namespace casestudy.Service
{
    internal class HRManagement : IHRManagement
    {
        readonly IEasypayRepository _HRManagement;

        public HRManagement()
        {
            _HRManagement = new IEasypayRepositoryImpl();
        }

        public int HRLogin()
        {
            Console.WriteLine("Enter your Email: ");
            string email = Console.ReadLine();
            Console.WriteLine("Enter your password:");
            string password = Console.ReadLine();
            if (_HRManagement.HRLogin(email, password) > 0)
            {
                Console.WriteLine("Login Successful");
                return 1;
            }
            else
            {
                Console.WriteLine("Incorrect Email Or Password \n Please Login Or Register to Continue");
                return 0;
            }
        }

        // Manage Employee Information
        public void AddEmployee()
        {
            Console.WriteLine("Enter Employee details:");

            Console.Write("FirstName: ");
            string FirstName = Console.ReadLine();

            Console.Write("LastName: ");
            string LastName = Console.ReadLine();

            Console.Write("Email: ");
            string Email = Console.ReadLine();

            Console.Write("phone: ");
            string phone = (Console.ReadLine());

            Console.Write("Address: ");
            string Address = Console.ReadLine();

            Console.Write("HireDate: ");
            DateTime HireDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Department: ");
            string Department = Console.ReadLine();

            Console.Write("Position: ");
            string Position = Console.ReadLine();

            Console.Write("Salary: ");
            decimal Salary = decimal.Parse(Console.ReadLine());


            Console.Write("UserID: ");
            int UserID = int.Parse(Console.ReadLine());

            Employee employee = new Employee(FirstName, LastName, Email, phone, Address, HireDate, Department, Position, Salary, UserID);

            int AddEmployeeStatus = _HRManagement.AddEmployee(employee);
            if (AddEmployeeStatus > 0)
            {
                Console.WriteLine("Employee Added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to Add Employee.");
            }
        }


        public void RemoveEmployee()
        {
            Console.Write("Enter the employee ID: ");
            int employeeID = int.Parse(Console.ReadLine());
            int removeEmployeeStatus = _HRManagement.RemoveEmployee(employeeID);

            if (removeEmployeeStatus > 0)
            {
                Console.WriteLine("Employee removed successfully.");
            }
            else
            {
                Console.WriteLine("Failed to remove Employee.");
            }
        }


        public void UpdateEmployee()
        {
            Console.Write("Enter the Employee ID to update: ");
            int employeeID = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter updated Employee details:");

            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Phone: ");
            string phone = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            Console.Write("Hire Date (yyyy-mm-dd): ");
            DateTime hireDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Department: ");
            string department = Console.ReadLine();

            Console.Write("Position: ");
            string position = Console.ReadLine();

            Console.Write("Salary: ");
            decimal salary = decimal.Parse(Console.ReadLine());

            Console.Write("UserID: ");
            int userID = int.Parse(Console.ReadLine());

            // Create a new Employee object with the updated information
            Employee updatedEmployee = new Employee(employeeID, firstName, lastName, email, phone, address, hireDate, department, position, salary, userID);

            // Call the UpdateEmployee method from the repository
            int updateEmployeeStatus = _HRManagement.UpdateEmployee(updatedEmployee);
            if (updateEmployeeStatus > 0)
            {
                Console.WriteLine("Employee updated successfully.");
            }
            else
            {
                Console.WriteLine("Failed to update employee.");
            }
        }



        // User Management
        public void AddUser()
        {
            Console.WriteLine("Enter User Details: ");

            Console.Write("Username: ");
            string Username = Console.ReadLine();

            Console.Write("password: ");
            string password = Console.ReadLine();

            Console.Write("RoleID: ");
            int RoleID = int.Parse(Console.ReadLine());

            User user = new User(Username, password, RoleID);

            int AddUserStatus = _HRManagement.AddUser(user);
            if (AddUserStatus > 0)
            {
                Console.WriteLine("User Added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to Add User.");


            }

        }


        public void RemoveUser()
        {
            Console.Write("enter the user id: ");
            int UserID = int.Parse(Console.ReadLine());
            int RemoveUserStatus = _HRManagement.RemoveUser(UserID);
            if (RemoveUserStatus > 0)
            {
                Console.WriteLine("User removed successfully.");
            }
            else
            {
                Console.WriteLine("Failed to remove User.");
            }
        }

        public void UpdateUser()
        {
            Console.Write("Enter the User ID to update: ");
            int UserID = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter updated User details:");

            Console.Write("Username: ");
            string Username = Console.ReadLine();

            Console.Write("Password: ");
            string Password = Console.ReadLine();

            Console.Write("RoleID: ");
            int RoleID = int.Parse(Console.ReadLine());

            // Create a new User object with the updated information
            User updatedUser = new User(UserID, Username, Password, RoleID);

            // Call the UpdateUser method from the repository
            int UpdateUserStatus = _HRManagement.UpdateUser(updatedUser);
            if (UpdateUserStatus > 0)
            {
                Console.WriteLine("User updated successfully.");
            }
            else
            {
                Console.WriteLine("Failed to update user.");
            }
        }


        // Define Payroll Policies
        public void DefinePayrollPolicy()
        {
            Console.WriteLine("Enter Policy Details: ");
            Console.Write("PolicyName: ");
            string PolicyName = Console.ReadLine();

            Console.Write("Description: ");
            string Description = Console.ReadLine();

            Console.Write("EffectiveDate: ");
            DateTime EffectiveDate = DateTime.Parse(Console.ReadLine());

            PayrollPolicy payrollpolicy = new PayrollPolicy(PolicyName, Description, EffectiveDate);
            int DefinePayrollStatus = _HRManagement.DefinePayrollPolicy(payrollpolicy);
            if (DefinePayrollStatus > 0)
            {
                Console.WriteLine("Policy defined successfully.");
            }
            else
            {
                Console.WriteLine("Failed to define policy.");
            }

        }
        public void GeneratePayroll()
        {
            Console.WriteLine("Enter Payroll Generation Details:");

            Console.Write("EmployeeID: ");
            int employeeID = int.Parse(Console.ReadLine());

            Console.Write("PayDate (yyyy-mm-dd): ");
            DateTime payDate = DateTime.Parse(Console.ReadLine());

            Payroll payroll = _HRManagement.GeneratePayroll(employeeID, payDate);
            if (payroll != null)
            {
                Console.WriteLine("Payroll generated successfully.");
                Console.WriteLine($"EmployeeID: {payroll.EmployeeID}");
                Console.WriteLine($"PayDate: {payroll.PayDate.ToShortDateString()}");
                Console.WriteLine($"GrossAmount: {payroll.GrossAmount:C}");
                Console.WriteLine($"Deductions: {payroll.Deductions:C}");
                Console.WriteLine($"NetAmount: {payroll.NetAmount:C}");
            }
            else
            {
                Console.WriteLine("Failed to generate payroll.");
            }
        }






        public List<ComplianceReportItem> GenerateComplianceReport()
        {
            Console.WriteLine("Generating Compliance Report...");

            Console.Write("Enter Start Date (yyyy-mm-dd): ");
            DateTime startDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter End Date (yyyy-mm-dd): ");
            DateTime endDate = DateTime.Parse(Console.ReadLine());

            // Fetch employee and payroll data between the specified dates
            var complianceReport = _HRManagement.GenerateComplianceReport(startDate, endDate);

            if (complianceReport != null && complianceReport.Count > 0)
            {
                Console.WriteLine("Compliance Report Generated Successfully.");
                Console.WriteLine("------------------------------------------------------");
                Console.WriteLine("EmployeeID | EmployeeName | PayDate | GrossAmount | Deductions | NetAmount");
                Console.WriteLine("------------------------------------------------------");

                foreach (var reportItem in complianceReport)
                {
                    Console.WriteLine($"{reportItem.EmployeeID} | {reportItem.EmployeeName} | {reportItem.PayDate.ToShortDateString()} | " +
                                      $"{reportItem.GrossAmount:C} | {reportItem.Deductions:C} | {reportItem.NetAmount:C}");
                }

                Console.WriteLine("------------------------------------------------------");
            }
            else
            {
                Console.WriteLine("No data found for the specified date range.");
            }
            return complianceReport;
        }


    }
}

   

