﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using casestudy.models;

namespace casestudy.DAO
{
    public class IEasypayRepositoryImpl : IEasypayRepository
    {
        SqlConnection sqlConnection = null;
        SqlCommand cmd = null;

        public IEasypayRepositoryImpl()
        {
            sqlConnection = new SqlConnection("Server=DESKTOP-BFMCOC6;DataBase=Easypay;Trusted_Connection=True");
            cmd = new SqlCommand();
        }

        public int HRLogin(string email, string password)
        {

            cmd.CommandText = "SELECT HR_ID FROM HRLogin WHERE Email = @Email AND Password = @Password";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                sqlConnection.Close();
                return 1;


            }
            sqlConnection.Close();
            return 0;





        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int AddEmployee(Employee employee)
        {
            cmd.CommandText = "INSERT INTO Employees (FirstName,LastName,Email,Phone,Address,HireDate,Department,Position,Salary,UserID) VALUES (@FirstName, @LastName, @Email, @Phone, @Address, @HireDate, @Department,@Position,@Salary,@UserID)";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FirstName", employee.FirstName);
            cmd.Parameters.AddWithValue("@LastName", employee.LastName);
            cmd.Parameters.AddWithValue("@Email", employee.Email);
            cmd.Parameters.AddWithValue("@Phone", employee.Phone);
            cmd.Parameters.AddWithValue("@Address", employee.Address);
            cmd.Parameters.AddWithValue("@HireDate", employee.HireDate);
            cmd.Parameters.AddWithValue("@Department", employee.Department);
            cmd.Parameters.AddWithValue("@Position", employee.Position);
            cmd.Parameters.AddWithValue("@Salary", employee.Salary);
            cmd.Parameters.AddWithValue("@UserID", employee.UserID);

            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int CreateEmployeeStatus = cmd.ExecuteNonQuery();
            sqlConnection.Close();
            return CreateEmployeeStatus;

        }
        public int RemoveEmployee(int employeeID)
        {
            int removeEmployeeStatus = 0;

            cmd.Connection = sqlConnection;

            try
            {
                sqlConnection.Open();

                // Remove related records in Payrolls table
                cmd.CommandText = "DELETE FROM Payrolls WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                cmd.ExecuteNonQuery();

                // Remove related records in LeaveRequests table
                cmd.CommandText = "DELETE FROM LeaveRequests WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                cmd.ExecuteNonQuery();

                // Remove related records in Benefits table
                cmd.CommandText = "DELETE FROM Benefits WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                cmd.ExecuteNonQuery();

                // Then, delete the employee
                cmd.CommandText = "DELETE FROM Employees WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                removeEmployeeStatus = cmd.ExecuteNonQuery();

                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }

            return removeEmployeeStatus;
        }


        public int UpdateEmployee(Employee employee)
        {
            int updateEmployeeStatus = 0;

            // Step 1: Check if the employee exists
            cmd.CommandText = "SELECT COUNT(*) FROM Employees WHERE EmployeeID = @EmployeeID";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);

            sqlConnection.Open();
            cmd.Connection = sqlConnection;

            // Get the count of employees with the given EmployeeID
            int employeeCount = 0;
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    employeeCount = reader.GetInt32(0); // Read the count
                }
            }
            sqlConnection.Close();

            // If employee not found, return failure
            if (employeeCount == 0)
            {
                return 0; // Employee does not exist
            }

            // Step 2: Update the employee information
            cmd.CommandText = @"
        UPDATE Employees
        SET FirstName = @FirstName,
            LastName = @LastName,
            Email = @Email,
            Phone = @Phone,
            Address = @Address,
            HireDate = @HireDate,
            Department = @Department,
            Position = @Position,
            Salary = @Salary,
            UserID = @UserID
        WHERE EmployeeID = @EmployeeID";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FirstName", employee.FirstName);
            cmd.Parameters.AddWithValue("@LastName", employee.LastName);
            cmd.Parameters.AddWithValue("@Email", employee.Email);
            cmd.Parameters.AddWithValue("@Phone", employee.Phone);
            cmd.Parameters.AddWithValue("@Address", employee.Address);
            cmd.Parameters.AddWithValue("@HireDate", employee.HireDate);
            cmd.Parameters.AddWithValue("@Department", employee.Department);
            cmd.Parameters.AddWithValue("@Position", employee.Position);
            cmd.Parameters.AddWithValue("@Salary", employee.Salary);
            cmd.Parameters.AddWithValue("@UserID", employee.UserID);
            cmd.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);

            try
            {
                sqlConnection.Open();
                updateEmployeeStatus = cmd.ExecuteNonQuery(); // Execute the update command
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
            }

            return updateEmployeeStatus; // Return the number of affected rows
        }



        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int AddUser(User user)
        {
            cmd.CommandText = "INSERT INTO Users (Username,Password,RoleID) VALUES (@Username, @Password, @RoleID)";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@Username", user.Username);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            cmd.Parameters.AddWithValue("@RoleID", user.RoleID);


            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int CreateUserStatus = cmd.ExecuteNonQuery();
            sqlConnection.Close();
            return CreateUserStatus;

        }

        public int RemoveUser(int userID)
        {
            int removeUserStatus = 0;

            cmd.CommandText = "DELETE FROM Users WHERE UserID = @userID";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@UserID", userID);

            cmd.Connection = sqlConnection;
            try
            {
                sqlConnection.Open();
                removeUserStatus = cmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);

            }

            return removeUserStatus;

        }

        public int UpdateUser(User user)
        {
            int updateUserStatus = 0;

            // Step 1: Check if the user exists
            cmd.CommandText = "SELECT COUNT(*) FROM Users WHERE UserID = @UserID";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@UserID", user.UserID);

           
            sqlConnection.Open();
            cmd.Connection = sqlConnection;
           

            // Get the count of users with the given UserID
            int userCount = 0;
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    userCount = reader.GetInt32(0); // Read the count
                }
            }
            sqlConnection.Close();

            // If user not found, return failure
            if (userCount == 0)
            {
                return 0; // User does not exist
            }

            // Step 2: Update the user information
            cmd.CommandText = @"
                UPDATE Users
                SET Username = @Username,
                    Password = @Password,
                    RoleID = @RoleID
                WHERE UserID = @UserID";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@Username", user.Username);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            cmd.Parameters.AddWithValue("@RoleID", user.RoleID);
            cmd.Parameters.AddWithValue("@UserID", user.UserID);

            try
            {
                sqlConnection.Open();
                updateUserStatus = cmd.ExecuteNonQuery(); // Execute the update command
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
            }

            return updateUserStatus; // Return the number of affected rows
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int DefinePayrollPolicy(PayrollPolicy payrollpolicy)
        {
            cmd.CommandText = "INSERT INTO PayrollPolicies (PolicyName,Description,EffectiveDate) VALUES (@PolicyName, @Description, @EffectiveDate)";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PolicyName", payrollpolicy.PolicyName);
            cmd.Parameters.AddWithValue("@Description", payrollpolicy.Description);
            cmd.Parameters.AddWithValue("@EffectiveDate", payrollpolicy.EffectiveDate);



            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int definePayrollStatus = cmd.ExecuteNonQuery();
            sqlConnection.Close();
            return definePayrollStatus;

        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        public Payroll GeneratePayroll(int employeeID, DateTime payDate)
        {
            Payroll payroll = null;

            decimal grossAmount = 0;
            decimal deductions = 0;
            decimal netAmount = 0;

            cmd.Connection = sqlConnection;

            try
            {
                // Step 1: Get Employee's Salary
                cmd.CommandText = "SELECT Salary FROM Employees WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);

                sqlConnection.Open();
                var salaryResult = cmd.ExecuteScalar();
                sqlConnection.Close();

                if (salaryResult != null)
                {
                    grossAmount = (decimal)salaryResult;
                }
                else
                {
                    // If employee not found, return null
                    return null;
                }

                // Step 2: Calculate total benefits for the employee
                cmd.CommandText = "SELECT SUM(Amount) FROM Benefits WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);

                sqlConnection.Open();
                var benefitsResult = cmd.ExecuteScalar();
                sqlConnection.Close();

                if (benefitsResult != null)
                {
                    grossAmount += (decimal)benefitsResult;
                }

                // Step 3: Calculate total deductions for the employee
                cmd.CommandText = "SELECT SUM(Amount) FROM Deductions WHERE EmployeeID = @EmployeeID";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);

                sqlConnection.Open();
                var deductionsResult = cmd.ExecuteScalar();
                sqlConnection.Close();

                if (deductionsResult != null)
                {
                    deductions = (decimal)deductionsResult;
                }

                // Step 4: Calculate net amount
                netAmount = grossAmount - deductions;

                // Step 5: Insert the payroll record into the Payrolls table
                cmd.CommandText = "INSERT INTO Payrolls (EmployeeID, PayDate, GrossAmount, Deductions, NetAmount) " +
                                  "VALUES (@EmployeeID, @PayDate, @GrossAmount, @Deductions, @NetAmount)";

                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                cmd.Parameters.AddWithValue("@PayDate", payDate);
                cmd.Parameters.AddWithValue("@GrossAmount", grossAmount);
                cmd.Parameters.AddWithValue("@Deductions", deductions);
                cmd.Parameters.AddWithValue("@NetAmount", netAmount);

                sqlConnection.Open();
                int generatePayrollStatus = cmd.ExecuteNonQuery();
                sqlConnection.Close();

                if (generatePayrollStatus > 0)
                {
                    payroll = new Payroll
                    {
                        EmployeeID = employeeID,
                        PayDate = payDate,
                        GrossAmount = grossAmount,
                        Deductions = deductions,
                        NetAmount = netAmount
                    };
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }

            return payroll;
        }





        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public List<ComplianceReportItem> GenerateComplianceReport(DateTime startDate, DateTime endDate)
        {
            List<ComplianceReportItem> reportItems = new List<ComplianceReportItem>();

            cmd.CommandText = @"
                SELECT e.EmployeeID, 
                       (e.FirstName + ' ' + e.LastName) as EmployeeName, 
                       p.PayDate, 
                       p.GrossAmount, 
                       p.Deductions, 
                       p.NetAmount
                FROM Employees e
                JOIN Payrolls p ON e.EmployeeID = p.EmployeeID
                WHERE p.PayDate BETWEEN @StartDate AND @EndDate";

            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@StartDate", startDate);
            cmd.Parameters.AddWithValue("@EndDate", endDate);

            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ComplianceReportItem item = new ComplianceReportItem
                {
                    EmployeeID = (int)reader["EmployeeID"],
                    EmployeeName = reader["EmployeeName"].ToString(),
                    PayDate = (DateTime)reader["PayDate"],
                    GrossAmount = (decimal)reader["GrossAmount"],
                    Deductions = (decimal)reader["Deductions"],
                    NetAmount = (decimal)reader["NetAmount"]
                };
                reportItems.Add(item);
            }

            sqlConnection.Close();
            return reportItems;
            
        }
    }
}
