﻿using casestudy.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace casestudy.DAO
{
    public interface IEasypayRepository
    {
        int HRLogin(string username, string password);
        int AddEmployee(Employee employee);
        int RemoveEmployee(int EmployeeID);

        int UpdateEmployee(Employee updatedEmployee);
        int AddUser(User user);

        int RemoveUser(int UserID);
        int UpdateUser(User updatedUser);

        int DefinePayrollPolicy(PayrollPolicy payrollpolicy);

       Payroll GeneratePayroll(int employeeID, DateTime payDate);

        List<ComplianceReportItem> GenerateComplianceReport(DateTime startDate, DateTime endDate);


    }
}
