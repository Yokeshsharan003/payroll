﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace casestudy.models
{
    public class Payroll
    {
        public int PayrollID { get; set; }
        public int EmployeeID { get; set; }
        public DateTime PayDate { get; set; }
        public decimal GrossAmount { get; set; }
        public decimal Deductions { get; set; }
        public decimal NetAmount { get; set; }
        public Employee Employee { get; set; }  // Navigation property

        // Default constructor
        public Payroll() { }

        // Parameterized constructor
        public Payroll(int employeeId, DateTime payDate, decimal grossAmount,
            decimal deductions, decimal netAmount)
        {
            EmployeeID = employeeId;
            PayDate = payDate;
            GrossAmount = grossAmount;
            Deductions = deductions;
            NetAmount = netAmount;
        }

        public Payroll(int employeeID, DateTime payDate)
        {
            EmployeeID = employeeID;
            PayDate = payDate;
        }
    }

}
