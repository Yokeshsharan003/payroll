﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace casestudy.models
{
    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }

        // Default constructor
        public Role() { }

        // Parameterized constructor
        public Role(string roleName)
        {
            RoleName = roleName;
        }
    }



}
